openssl ocsp -issuer stores/root-ca/root-ca.crt -CAfile stores/root-ca/root-ca.crt -cert stores/root-ca/root-ocsp.crt -url http://localhost:9080
